import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("smm.db");
const JWT_SECRET = process.env.JWT_SECRET || "smm-panel-secret-key-123";

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT,
    security_answer TEXT,
    balance REAL DEFAULT 0.0,
    role TEXT DEFAULT 'user'
  );

  CREATE TABLE IF NOT EXISTS services (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    category TEXT,
    rate REAL,
    min_order INTEGER,
    max_order INTEGER,
    description TEXT
  );

  CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    service_id INTEGER,
    link TEXT,
    quantity INTEGER,
    charge REAL,
    status TEXT DEFAULT 'Pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(service_id) REFERENCES services(id)
  );

  CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    amount REAL,
    transaction_id TEXT,
    status TEXT DEFAULT 'Pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS friends (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    friend_id INTEGER,
    status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(friend_id) REFERENCES users(id)
  );
`);

// Seed initial services if empty
const serviceCount = db.prepare("SELECT count(*) as count FROM services").get() as { count: number };
if (serviceCount.count === 0) {
  const insertService = db.prepare("INSERT INTO services (name, category, rate, min_order, max_order, description) VALUES (?, ?, ?, ?, ?, ?)");
  insertService.run("Instagram Followers [100% Real - Non Drop]", "Instagram", 80.00, 100, 50000, "Premium quality real followers that never drop. Lifetime guarantee.");
  insertService.run("Instagram Likes [Real - Non Drop]", "Instagram", 30.00, 50, 10000, "Real likes from active accounts. Non-drop guarantee.");
  insertService.run("Instagram Views [Fast Delivery]", "Instagram", 0.70, 100, 1000000, "High quality fast views. ₹7 for 10000 views.");
}

// Remove any existing YouTube, Facebook, or Twitter services
db.exec("DELETE FROM services WHERE category IN ('YouTube', 'Facebook', 'Twitter')");

// Update existing Instagram prices to match new requirements
db.exec("UPDATE services SET rate = 80.00 WHERE category = 'Instagram' AND name LIKE '%Followers%'");
db.exec("UPDATE services SET rate = 30.00 WHERE category = 'Instagram' AND name LIKE '%Likes%'");

// Ensure Instagram Views exists
const viewsCount = db.prepare("SELECT count(*) as count FROM services WHERE category = 'Instagram' AND name LIKE '%Views%'").get() as { count: number };
if (viewsCount.count === 0) {
  db.prepare("INSERT INTO services (name, category, rate, min_order, max_order, description) VALUES (?, ?, ?, ?, ?, ?)").run("Instagram Views [Fast Delivery]", "Instagram", 0.70, 100, 1000000, "High quality fast views. ₹7 for 10000 views.");
}

async function startServer() {
  // Initialize default admin user
  const adminUser = db.prepare("SELECT * FROM users WHERE username = 'admin'").get();
  if (!adminUser) {
    const hashedAdminPass = await bcrypt.hash('Djdj9867', 10);
    const hashedAnswer = await bcrypt.hash('admin', 10);
    db.prepare("INSERT INTO users (username, password, security_answer, role) VALUES (?, ?, ?, ?)").run('admin', hashedAdminPass, hashedAnswer, 'admin');
  } else {
    // Reset existing admin password to Djdj9867 for the user
    const hashedAdminPass = await bcrypt.hash('Djdj9867', 10);
    db.prepare("UPDATE users SET password = ?, role = 'admin' WHERE username = 'admin'").run(hashedAdminPass);
  }

  const app = express();
  app.use(express.json());

  // Auth Middleware
  const authenticateToken = (req: any, res: any, next: any) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) return res.status(401).json({ error: "Unauthorized" });

    jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
      if (err) return res.status(403).json({ error: "Forbidden" });
      req.user = user;
      next();
    });
  };

  const isAdmin = (req: any, res: any, next: any) => {
    const user = db.prepare("SELECT role FROM users WHERE id = ?").get(req.user.id) as any;
    if (user && user.role === 'admin') {
      next();
    } else {
      res.status(403).json({ error: "Admin access required" });
    }
  };

  // API Routes
  app.post("/api/register", async (req, res) => {
    const { username, password, securityAnswer } = req.body;
    try {
      const hashedPassword = await bcrypt.hash(password, 10);
      const hashedAnswer = await bcrypt.hash(securityAnswer.toLowerCase(), 10);
      const info = db.prepare("INSERT INTO users (username, password, security_answer, balance) VALUES (?, ?, ?, ?)").run(username, hashedPassword, hashedAnswer, 0.0); // Start with $0 balance
      res.json({ success: true, userId: info.lastInsertRowid });
    } catch (err) {
      res.status(400).json({ error: "Username already exists" });
    }
  });

  app.post("/api/reset-password", async (req, res) => {
    const { username, securityAnswer, newPassword } = req.body;
    const user = db.prepare("SELECT * FROM users WHERE username = ?").get(username) as any;
    
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    const isAnswerCorrect = await bcrypt.compare(securityAnswer.toLowerCase(), user.security_answer);
    if (!isAnswerCorrect) {
      return res.status(401).json({ error: "Incorrect security answer" });
    }

    const hashedNewPassword = await bcrypt.hash(newPassword, 10);
    db.prepare("UPDATE users SET password = ? WHERE id = ?").run(hashedNewPassword, user.id);
    
    res.json({ success: true, message: "Password reset successfully" });
  });

  app.post("/api/login", async (req, res) => {
    const { username, password } = req.body;
    const user = db.prepare("SELECT * FROM users WHERE username = ?").get(username) as any;
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ error: "Invalid credentials" });
    }
    const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET);

    res.json({ token, user: { id: user.id, username: user.username, balance: user.balance, role: user.role } });
  });

  app.get("/api/user", authenticateToken, (req: any, res) => {
    const user = db.prepare("SELECT id, username, balance, role FROM users WHERE id = ?").get(req.user.id);
    res.json(user);
  });

  // Friends API Routes
  app.get("/api/friends", authenticateToken, (req: any, res: any) => {
    const userId = req.user.id;
    
    // Get accepted friends
    const friends = db.prepare(`
      SELECT u.id, u.username, f.created_at
      FROM friends f
      JOIN users u ON (f.user_id = u.id OR f.friend_id = u.id)
      WHERE (f.user_id = ? OR f.friend_id = ?) AND f.status = 'accepted' AND u.id != ?
    `).all(userId, userId, userId);

    // Get pending requests (where friend_id is me)
    const pending = db.prepare(`
      SELECT f.id as request_id, u.id as user_id, u.username, f.created_at
      FROM friends f
      JOIN users u ON f.user_id = u.id
      WHERE f.friend_id = ? AND f.status = 'pending'
    `).all(userId);

    // Get sent requests (where user_id is me)
    const sent = db.prepare(`
      SELECT f.id as request_id, u.id as user_id, u.username, f.created_at
      FROM friends f
      JOIN users u ON f.friend_id = u.id
      WHERE f.user_id = ? AND f.status = 'pending'
    `).all(userId);

    res.json({ friends, pending, sent });
  });

  app.post("/api/friends/request", authenticateToken, (req: any, res: any) => {
    const { username } = req.body;
    const friend = db.prepare("SELECT id FROM users WHERE username = ?").get(username) as any;
    
    if (!friend) return res.status(404).json({ error: "Player not found" });
    if (friend.id === req.user.id) return res.status(400).json({ error: "You cannot add yourself to your squad" });

    // Check if already friends or pending
    const existing = db.prepare("SELECT * FROM friends WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)").get(req.user.id, friend.id, friend.id, req.user.id);
    if (existing) return res.status(400).json({ error: "Invite already sent or player is already in your squad" });

    db.prepare("INSERT INTO friends (user_id, friend_id) VALUES (?, ?)").run(req.user.id, friend.id);
    res.json({ success: true, message: "Invite sent successfully" });
  });

  app.post("/api/friends/accept", authenticateToken, (req: any, res: any) => {
    const { requestId } = req.body;
    db.prepare("UPDATE friends SET status = 'accepted' WHERE id = ? AND friend_id = ?").run(requestId, req.user.id);
    res.json({ success: true });
  });

  app.post("/api/friends/reject", authenticateToken, (req: any, res: any) => {
    const { requestId } = req.body;
    db.prepare("DELETE FROM friends WHERE id = ? AND friend_id = ?").run(requestId, req.user.id);
    res.json({ success: true });
  });

  app.get("/api/services", (req, res) => {
    const services = db.prepare("SELECT * FROM services").all();
    res.json(services);
  });

  app.get("/api/orders", authenticateToken, (req: any, res) => {
    const orders = db.prepare(`
      SELECT o.*, s.name as service_name 
      FROM orders o 
      JOIN services s ON o.service_id = s.id 
      WHERE o.user_id = ? 
      ORDER BY o.created_at DESC
    `).all(req.user.id);
    res.json(orders);
  });

  app.post("/api/orders", authenticateToken, (req: any, res) => {
    const { serviceId, link, quantity } = req.body;
    const service = db.prepare("SELECT * FROM services WHERE id = ?").get(serviceId) as any;
    const user = db.prepare("SELECT * FROM users WHERE id = ?").get(req.user.id) as any;

    if (!service) return res.status(404).json({ error: "Service not found" });
    
    const charge = (service.rate * quantity) / 1000;
    if (user.balance < charge) {
      return res.status(400).json({ error: "Insufficient balance" });
    }

    db.transaction(() => {
      db.prepare("UPDATE users SET balance = balance - ? WHERE id = ?").run(charge, user.id);
      db.prepare("INSERT INTO orders (user_id, service_id, link, quantity, charge) VALUES (?, ?, ?, ?, ?)")
        .run(user.id, serviceId, link, quantity, charge);
    })();

    res.json({ success: true, charge });
  });

  // Admin API Routes
  app.get("/api/admin/stats", authenticateToken, isAdmin, (req, res) => {
    const totalUsers = db.prepare("SELECT count(*) as count FROM users").get() as any;
    const totalOrders = db.prepare("SELECT count(*) as count FROM orders").get() as any;
    const totalRevenue = db.prepare("SELECT sum(charge) as sum FROM orders").get() as any;
    const pendingPayments = db.prepare("SELECT count(*) as count FROM payments WHERE status = 'Pending'").get() as any;
    res.json({
      users: totalUsers.count,
      orders: totalOrders.count,
      revenue: totalRevenue.sum || 0,
      pendingPayments: pendingPayments.count || 0
    });
  });

  app.get("/api/admin/users", authenticateToken, isAdmin, (req, res) => {
    const users = db.prepare("SELECT id, username, balance, role FROM users").all();
    res.json(users);
  });

  app.post("/api/admin/users/balance", authenticateToken, isAdmin, (req, res) => {
    const { userId, amount } = req.body;
    db.prepare("UPDATE users SET balance = balance + ? WHERE id = ?").run(amount, userId);
    res.json({ success: true });
  });

  app.get("/api/admin/orders", authenticateToken, isAdmin, (req, res) => {
    const orders = db.prepare(`
      SELECT o.*, u.username, s.name as service_name 
      FROM orders o 
      JOIN users u ON o.user_id = u.id
      JOIN services s ON o.service_id = s.id 
      ORDER BY o.created_at DESC
    `).all();
    res.json(orders);
  });

  app.post("/api/admin/orders/status", authenticateToken, isAdmin, (req, res) => {
    const { orderId, status } = req.body;
    db.prepare("UPDATE orders SET status = ? WHERE id = ?").run(status, orderId);
    res.json({ success: true });
  });

  app.post("/api/admin/services", authenticateToken, isAdmin, (req, res) => {
    const { name, category, rate, min_order, max_order, description } = req.body;
    db.prepare("INSERT INTO services (name, category, rate, min_order, max_order, description) VALUES (?, ?, ?, ?, ?, ?)")
      .run(name, category, rate, min_order, max_order, description);
    res.json({ success: true });
  });

  app.delete("/api/admin/services/:id", authenticateToken, isAdmin, (req, res) => {
    db.prepare("DELETE FROM services WHERE id = ?").run(req.params.id);
    res.json({ success: true });
  });

  app.post("/api/payments", authenticateToken, (req: any, res: any) => {
    const { amount, transaction_id } = req.body;
    db.prepare("INSERT INTO payments (user_id, amount, transaction_id) VALUES (?, ?, ?)").run(req.user.id, amount, transaction_id);
    res.json({ success: true });
  });

  app.get("/api/admin/payments", authenticateToken, isAdmin, (req: any, res: any) => {
    const payments = db.prepare(`
      SELECT p.*, u.username 
      FROM payments p 
      JOIN users u ON p.user_id = u.id 
      ORDER BY p.created_at DESC
    `).all();
    res.json(payments);
  });

  app.post("/api/admin/payments/approve", authenticateToken, isAdmin, (req: any, res: any) => {
    const { paymentId } = req.body;
    const payment = db.prepare("SELECT * FROM payments WHERE id = ?").get(paymentId) as any;
    if (payment && payment.status === 'Pending') {
      db.transaction(() => {
        db.prepare("UPDATE payments SET status = 'Successful' WHERE id = ?").run(paymentId);
        db.prepare("UPDATE users SET balance = balance + ? WHERE id = ?").run(payment.amount, payment.user_id);
      })();
      res.json({ success: true });
    } else {
      res.status(400).json({ error: "Invalid payment or already processed" });
    }
  });

  app.post("/api/admin/payments/reject", authenticateToken, isAdmin, (req: any, res: any) => {
    const { paymentId } = req.body;
    db.prepare("UPDATE payments SET status = 'Rejected' WHERE id = ?").run(paymentId);
    res.json({ success: true });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  const PORT = 3000;
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
