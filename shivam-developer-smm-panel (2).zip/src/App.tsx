import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Link, useNavigate, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  ShoppingCart, 
  List, 
  History, 
  User as UserIcon, 
  LogOut, 
  Menu, 
  X,
  TrendingUp,
  ShieldCheck,
  Zap,
  DollarSign,
  Shield,
  Users,
  Plus,
  Trash2,
  Wallet,
  Gamepad2,
  UserPlus,
  UserCheck,
  UserX,
  Headset
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { User, Service, Order } from './types';

// --- Components ---

const Sidebar = ({ user, onLogout }: { user: User | null, onLogout: () => void }) => {
  return (
    <div className="hidden lg:flex flex-col w-64 bg-[#151619] border-r border-white/5 h-screen sticky top-0">
      <div className="p-6 flex items-center gap-3 border-b border-white/5">
        <div className="w-10 h-10 bg-emerald-500 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/20">
          <TrendingUp className="text-black w-6 h-6" />
        </div>
        <div>
          <span className="text-xl font-bold tracking-tight text-white block">SMM<span className="text-emerald-500">PRO</span></span>
          <span className="text-[10px] text-emerald-500 font-mono font-bold uppercase tracking-widest">Shivam Developer</span>
        </div>
      </div>

      <div className="flex-1 py-6 px-4 space-y-2 overflow-y-auto">
        {user ? (
          <>
            <SidebarLink to="/dashboard" icon={<LayoutDashboard className="w-5 h-5" />} label="Dashboard" />
            <SidebarLink to="/new-order" icon={<ShoppingCart className="w-5 h-5" />} label="New Order" />
            <SidebarLink to="/services" icon={<List className="w-5 h-5" />} label="Services" />
            <SidebarLink to="/orders" icon={<History className="w-5 h-5" />} label="Orders" />
            <SidebarLink to="/add-funds" icon={<Wallet className="w-5 h-5" />} label="Add Funds" />
            <SidebarLink to="/friends" icon={<Gamepad2 className="w-5 h-5" />} label="Squad" />
            
            <div className="pt-2">
              <a 
                href="https://wa.me/918929504104" 
                target="_blank" 
                rel="noreferrer"
                className="flex items-center gap-3 px-4 py-3 text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/10 rounded-xl transition-all group font-medium"
              >
                <span className="group-hover:scale-110 transition-transform"><Headset className="w-5 h-5" /></span>
                Support: 8929504104
              </a>
            </div>

            {user.role === 'admin' && (
              <SidebarLink to="/admin" icon={<Shield className="w-5 h-5 text-emerald-500" />} label="Admin Panel" />
            )}
            
            <div className="pt-6 mt-6 border-t border-white/5">
              <div className="bg-emerald-500/5 p-4 rounded-xl border border-emerald-500/10 mb-4">
                <p className="text-gray-500 text-[10px] uppercase tracking-widest font-bold mb-1">Your Balance</p>
                <div className="flex items-center gap-2">
                  <DollarSign className="w-4 h-4 text-emerald-500" />
                  <span className="text-xl font-bold text-white font-mono">₹{user.balance.toFixed(2)}</span>
                </div>
              </div>
              <button 
                onClick={onLogout}
                className="w-full flex items-center gap-3 px-4 py-3 text-gray-400 hover:text-red-400 hover:bg-red-400/5 rounded-xl transition-all"
              >
                <LogOut className="w-5 h-5" />
                <span className="font-medium">Sign Out</span>
              </button>
            </div>
          </>
        ) : (
          <>
            <SidebarLink to="/login" icon={<UserIcon className="w-5 h-5" />} label="Login" />
            <SidebarLink to="/register" icon={<Zap className="w-5 h-5" />} label="Register" />
          </>
        )}
      </div>

      <div className="p-6 border-t border-white/5">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center">
            <UserIcon className="w-4 h-4 text-gray-400" />
          </div>
          <div className="overflow-hidden">
            <p className="text-sm font-medium text-white truncate">{user?.username || 'Guest'}</p>
            <p className="text-[10px] text-gray-500 uppercase tracking-widest">Developer Mode</p>
          </div>
        </div>
      </div>
    </div>
  );
};

const SidebarLink = ({ to, icon, label }: { to: string, icon: React.ReactNode, label: string }) => (
  <Link 
    to={to} 
    className="flex items-center gap-3 px-4 py-3 text-gray-400 hover:text-white hover:bg-white/5 rounded-xl transition-all group"
  >
    <span className="group-hover:text-emerald-500 transition-colors">{icon}</span>
    <span className="font-medium">{label}</span>
  </Link>
);

const Navbar = ({ user, onLogout }: { user: User | null, onLogout: () => void }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="lg:hidden bg-[#151619] border-b border-white/5 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
              <TrendingUp className="text-black w-5 h-5" />
            </div>
            <div>
              <span className="text-lg font-bold tracking-tight text-white">SMM<span className="text-emerald-500">PRO</span></span>
              <span className="text-[8px] text-emerald-500 font-mono block -mt-1 uppercase">Shivam Developer</span>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            {user && (
              <div className="bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
                <span className="text-emerald-500 font-mono text-xs font-bold">₹{user.balance.toFixed(2)}</span>
              </div>
            )}
            <button onClick={() => setIsOpen(!isOpen)} className="text-gray-400 hover:text-white">
              {isOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-[#1a1b1e] border-b border-white/5"
          >
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              {user ? (
                <>
                  <Link to="/dashboard" onClick={() => setIsOpen(false)} className="text-gray-300 block px-3 py-2 rounded-md text-base font-medium">Dashboard</Link>
                  <Link to="/new-order" onClick={() => setIsOpen(false)} className="text-gray-300 block px-3 py-2 rounded-md text-base font-medium">New Order</Link>
                  <Link to="/services" onClick={() => setIsOpen(false)} className="text-gray-300 block px-3 py-2 rounded-md text-base font-medium">Services</Link>
                  <Link to="/orders" onClick={() => setIsOpen(false)} className="text-gray-300 block px-3 py-2 rounded-md text-base font-medium">Orders</Link>
                  <Link to="/add-funds" onClick={() => setIsOpen(false)} className="text-gray-300 block px-3 py-2 rounded-md text-base font-medium">Add Funds</Link>
                  <Link to="/friends" onClick={() => setIsOpen(false)} className="text-gray-300 block px-3 py-2 rounded-md text-base font-medium">Squad</Link>
                  <a href="https://wa.me/918929504104" target="_blank" rel="noreferrer" onClick={() => setIsOpen(false)} className="text-emerald-400 block px-3 py-2 rounded-md text-base font-medium">
                    Support: 8929504104
                  </a>
                  {user.role === 'admin' && (
                    <Link to="/admin" onClick={() => setIsOpen(false)} className="text-emerald-500 block px-3 py-2 rounded-md text-base font-medium">Admin Panel</Link>
                  )}
                  <div className="pt-4 pb-3 border-t border-white/10">
                    <button onClick={() => { onLogout(); setIsOpen(false); }} className="block w-full text-left px-3 py-2 rounded-md text-base font-medium text-gray-400 hover:text-white">Sign out</button>
                  </div>
                </>
              ) : (
                <>
                  <Link to="/login" onClick={() => setIsOpen(false)} className="text-gray-300 block px-3 py-2 rounded-md text-base font-medium">Login</Link>
                  <Link to="/register" onClick={() => setIsOpen(false)} className="text-emerald-500 block px-3 py-2 rounded-md text-base font-medium">Register</Link>
                </>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const LoginPage = ({ onLogin, type }: { onLogin: (token: string, user: User) => void, type: 'login' | 'register' | 'reset' }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [securityAnswer, setSecurityAnswer] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    
    let endpoint = '';
    let body = {};

    if (type === 'login') {
      endpoint = '/api/login';
      body = { username, password };
    } else if (type === 'register') {
      endpoint = '/api/register';
      body = { username, password, securityAnswer };
    } else if (type === 'reset') {
      endpoint = '/api/reset-password';
      body = { username, securityAnswer, newPassword };
    }

    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      const data = await res.json();
      if (res.ok) {
        if (type === 'login') {
          onLogin(data.token, data.user);
          navigate('/dashboard');
        } else if (type === 'register') {
          setSuccess('Account created! Please login.');
          setTimeout(() => navigate('/login'), 2000);
        } else if (type === 'reset') {
          setSuccess('Password reset successful! Please login.');
          setTimeout(() => navigate('/login'), 2000);
        }
      } else {
        setError(data.error);
      }
    } catch (err) {
      setError('Something went wrong');
    }
  };

  const title = type === 'login' ? 'Welcome Back' : type === 'register' ? 'Create Account' : 'Reset Password';
  const subtitle = type === 'login' ? 'Enter your credentials to access your panel' : type === 'register' ? 'Join thousands of users growing their social presence' : 'Enter your details to reset your password';

  return (
    <div className="min-h-[calc(100vh-64px)] flex items-center justify-center px-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full bg-[#151619] p-8 rounded-2xl border border-white/5 shadow-2xl"
      >
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">{title}</h2>
          <p className="text-gray-400 text-sm">{subtitle}</p>
        </div>

        {error && <div className="bg-red-500/10 border border-red-500/20 text-red-500 p-3 rounded-lg text-sm mb-6">{error}</div>}
        {success && <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-500 p-3 rounded-lg text-sm mb-6">{success}</div>}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Username</label>
            <input 
              type="text" 
              required 
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-[#1a1b1e] border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
              placeholder="Enter username"
            />
          </div>

          {type !== 'reset' && (
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">Password</label>
              <input 
                type="password" 
                required 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-[#1a1b1e] border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
                placeholder="••••••••"
              />
            </div>
          )}

          {type === 'register' && (
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">Security Question: What is your favorite color?</label>
              <input 
                type="text" 
                required 
                value={securityAnswer}
                onChange={(e) => setSecurityAnswer(e.target.value)}
                className="w-full bg-[#1a1b1e] border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
                placeholder="Your answer"
              />
            </div>
          )}

          {type === 'reset' && (
            <>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Security Answer (Favorite Color)</label>
                <input 
                  type="text" 
                  required 
                  value={securityAnswer}
                  onChange={(e) => setSecurityAnswer(e.target.value)}
                  className="w-full bg-[#1a1b1e] border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
                  placeholder="Your answer"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">New Password</label>
                <input 
                  type="password" 
                  required 
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full bg-[#1a1b1e] border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
                  placeholder="••••••••"
                />
              </div>
            </>
          )}

          <button 
            type="submit" 
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 rounded-xl transition-all shadow-lg shadow-emerald-600/20"
          >
            {type === 'login' ? 'Sign In' : type === 'register' ? 'Create Account' : 'Reset Password'}
          </button>
        </form>

        <div className="mt-6 text-center space-y-2">
          <p className="text-gray-400 text-sm">
            {type === 'login' ? "Don't have an account? " : "Already have an account? "}
            <Link to={type === 'login' ? '/register' : '/login'} className="text-emerald-500 hover:underline font-medium">
              {type === 'login' ? 'Register here' : 'Login here'}
            </Link>
          </p>
          {type === 'login' && (
            <p className="text-gray-400 text-sm">
              <Link to="/reset-password" stroke-emerald-500 className="text-emerald-500 hover:underline font-medium">
                Forgot Password?
              </Link>
            </p>
          )}
        </div>
      </motion.div>
    </div>
  );
};

const Dashboard = ({ user, token }: { user: User, token: string }) => {
  const [orderCount, setOrderCount] = useState(0);

  useEffect(() => {
    fetch('/api/orders', {
      headers: { 'Authorization': `Bearer ${token}` }
    })
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setOrderCount(data.length);
        }
      });
  }, [token]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-[#151619] p-6 rounded-2xl border border-white/5"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-emerald-500/10 rounded-xl">
              <DollarSign className="text-emerald-500 w-6 h-6" />
            </div>
            <span className="text-xs font-mono text-gray-500 uppercase tracking-widest">Balance</span>
          </div>
          <h3 className="text-3xl font-bold text-white">₹{user.balance.toFixed(2)}</h3>
          <p className="text-gray-500 text-sm mt-2">Available for new orders</p>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="bg-[#151619] p-6 rounded-2xl border border-white/5"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-blue-500/10 rounded-xl">
              <ShoppingCart className="text-blue-500 w-6 h-6" />
            </div>
            <span className="text-xs font-mono text-gray-500 uppercase tracking-widest">Total Orders</span>
          </div>
          <h3 className="text-3xl font-bold text-white">{orderCount}</h3>
          <p className="text-gray-500 text-sm mt-2">Orders placed so far</p>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
          className="bg-[#151619] p-6 rounded-2xl border border-white/5"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-purple-500/10 rounded-xl">
              <Zap className="text-purple-500 w-6 h-6" />
            </div>
            <span className="text-xs font-mono text-gray-500 uppercase tracking-widest">Status</span>
          </div>
          <h3 className="text-3xl font-bold text-white">Active</h3>
          <p className="text-gray-500 text-sm mt-2">Account is in good standing</p>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-[#151619] p-8 rounded-2xl border border-white/5">
          <h4 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
            <Zap className="text-yellow-500" />
            Featured Services (Non-Drop)
          </h4>
          <div className="space-y-4">
            <div className="p-4 bg-white/5 rounded-xl border border-white/5 hover:bg-white/10 transition-all cursor-pointer group">
              <div className="flex justify-between items-center">
                <div>
                  <h5 className="text-white font-medium group-hover:text-emerald-500 transition-colors">Instagram Views [Fast Delivery]</h5>
                  <p className="text-gray-500 text-xs">₹7 for 10000 Views • Instant</p>
                </div>
                <span className="text-emerald-500 font-mono font-bold">₹0.70</span>
              </div>
            </div>
            <div className="p-4 bg-white/5 rounded-xl border border-white/5 hover:bg-white/10 transition-all cursor-pointer group">
              <div className="flex justify-between items-center">
                <div>
                  <h5 className="text-white font-medium group-hover:text-emerald-500 transition-colors">Instagram Followers [100% Real]</h5>
                  <p className="text-gray-500 text-xs">Non-Drop • Lifetime Guarantee</p>
                </div>
                <span className="text-emerald-500 font-mono font-bold">₹80.00</span>
              </div>
            </div>
            <div className="p-4 bg-white/5 rounded-xl border border-white/5 hover:bg-white/10 transition-all cursor-pointer group">
              <div className="flex justify-between items-center">
                <div>
                  <h5 className="text-white font-medium group-hover:text-emerald-500 transition-colors">Instagram Likes [Real]</h5>
                  <p className="text-gray-500 text-xs">High Quality • Non-Drop</p>
                </div>
                <span className="text-emerald-500 font-mono font-bold">₹30.00</span>
              </div>
            </div>
          </div>
          <Link to="/new-order" className="mt-6 block w-full text-center text-sm text-emerald-500 hover:text-emerald-400 font-medium">
            View All Services →
          </Link>
        </div>

        <div className="bg-[#151619] p-8 rounded-2xl border border-white/5">
          <h4 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
            <ShieldCheck className="text-emerald-500" />
            Why Choose Us?
          </h4>
          <ul className="space-y-4">
            <li className="flex items-start gap-3">
              <div className="mt-1 w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
              <p className="text-gray-400 text-sm">Instant delivery on 90% of our services.</p>
            </li>
            <li className="flex items-start gap-3">
              <div className="mt-1 w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
              <p className="text-gray-400 text-sm">24/7 Customer support for all your queries.</p>
            </li>
            <li className="flex items-start gap-3">
              <div className="mt-1 w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
              <p className="text-gray-400 text-sm">Cheapest rates in the market with high quality.</p>
            </li>
          </ul>
          <Link to="/new-order" className="mt-8 block w-full bg-white/5 hover:bg-white/10 text-white text-center py-3 rounded-xl transition-all border border-white/10">
            Place Your First Order
          </Link>
        </div>

        <div className="bg-[#151619] p-8 rounded-2xl border border-white/5">
          <h4 className="text-xl font-bold text-white mb-6">Latest Announcements</h4>
          <div className="space-y-6">
            <div className="border-l-2 border-emerald-500 pl-4">
              <span className="text-xs text-emerald-500 font-mono">MAR 09, 2026</span>
              <h5 className="text-white font-medium mt-1">New Instagram Services Added</h5>
              <p className="text-gray-500 text-sm mt-1">We have added high-quality non-drop followers for Instagram.</p>
            </div>
            <div className="border-l-2 border-blue-500 pl-4">
              <span className="text-xs text-blue-500 font-mono">MAR 05, 2026</span>
              <h5 className="text-white font-medium mt-1">System Maintenance Complete</h5>
              <p className="text-gray-500 text-sm mt-1">All orders are now processing at lightning speed.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const NewOrder = ({ token, onOrderSuccess }: { token: string, onOrderSuccess: () => void }) => {
  const [services, setServices] = useState<Service[]>([]);
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [link, setLink] = useState('');
  const [quantity, setQuantity] = useState<number>(0);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState({ text: '', type: '' });
  const location = useLocation();

  useEffect(() => {
    fetch('/api/services')
      .then(res => res.json())
      .then(data => {
        setServices(data);
        const params = new URLSearchParams(location.search);
        const serviceIdParam = params.get('serviceId');
        if (serviceIdParam) {
          const s = data.find((s: Service) => s.id === parseInt(serviceIdParam));
          if (s) setSelectedService(s);
          else if (data.length > 0) setSelectedService(data[0]);
        } else if (data.length > 0) {
          setSelectedService(data[0]);
        }
      });
  }, [location.search]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedService) return;
    
    setLoading(true);
    setMessage({ text: '', type: '' });

    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ serviceId: selectedService.id, link, quantity })
      });
      const data = await res.json();
      if (res.ok) {
        setMessage({ text: `Order placed successfully! Charge: ₹${data.charge.toFixed(2)}`, type: 'success' });
        setLink('');
        setQuantity(0);
        onOrderSuccess();
      } else {
        setMessage({ text: data.error, type: 'error' });
      }
    } catch (err) {
      setMessage({ text: 'Failed to place order', type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  const charge = selectedService ? (selectedService.rate * quantity) / 1000 : 0;

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-[#151619] p-8 rounded-2xl border border-white/5 shadow-xl"
      >
        <h2 className="text-2xl font-bold text-white mb-8 flex items-center gap-2">
          <ShoppingCart className="text-emerald-500" />
          Place New Order
        </h2>

        {message.text && (
          <div className={`p-4 rounded-xl mb-6 text-sm ${message.type === 'success' ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20' : 'bg-red-500/10 text-red-500 border border-red-500/20'}`}>
            {message.text}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Category</label>
            <select className="w-full bg-[#1a1b1e] border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50">
              <option>All Services</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Service</label>
            <select 
              className="w-full bg-[#1a1b1e] border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
              onChange={(e) => {
                const s = services.find(s => s.id === parseInt(e.target.value));
                if (s) setSelectedService(s);
              }}
              value={selectedService?.id || ''}
            >
              {services.map(s => (
                <option key={s.id} value={s.id}>{s.name} - ₹{s.rate.toFixed(2)} per 1000</option>
              ))}
            </select>
          </div>

          {selectedService && (
            <div className="bg-white/5 p-4 rounded-xl border border-white/5 text-sm text-gray-400">
              <p className="font-medium text-white mb-1">Description:</p>
              <p>{selectedService.description}</p>
              <div className="mt-2 flex gap-4 text-xs">
                <span>Min: {selectedService.min_order}</span>
                <span>Max: {selectedService.max_order}</span>
              </div>
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Link</label>
            <input 
              type="url" 
              required 
              value={link}
              onChange={(e) => setLink(e.target.value)}
              className="w-full bg-[#1a1b1e] border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
              placeholder="https://www.instagram.com/p/..."
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Quantity</label>
            <input 
              type="number" 
              required 
              min={selectedService?.min_order || 0}
              max={selectedService?.max_order || 1000000}
              value={quantity || ''}
              onChange={(e) => setQuantity(parseInt(e.target.value) || 0)}
              className="w-full bg-[#1a1b1e] border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
              placeholder="0"
            />
          </div>

          <div className="bg-emerald-500/5 p-4 rounded-xl border border-emerald-500/10">
            <div className="flex justify-between items-center">
              <span className="text-gray-400 text-sm">Total Charge</span>
              <span className="text-2xl font-bold text-emerald-500 font-mono">₹{charge.toFixed(2)}</span>
            </div>
          </div>

          <button 
            type="submit" 
            disabled={loading}
            className="w-full bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold py-4 rounded-xl transition-all shadow-lg shadow-emerald-600/20"
          >
            {loading ? 'Processing...' : 'Place Order'}
          </button>
        </form>
      </motion.div>
    </div>
  );
};

const ServicesList = () => {
  const [services, setServices] = useState<Service[]>([]);

  useEffect(() => {
    fetch('/api/services')
      .then(res => res.json())
      .then(setServices);
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-white mb-2">Our Services</h2>
        <p className="text-gray-400">Browse our wide range of social media growth services</p>
      </div>

      <div className="bg-[#151619] rounded-2xl border border-white/5 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-white/5 border-b border-white/10">
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase tracking-widest">ID</th>
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase tracking-widest">Service</th>
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase tracking-widest">Rate per 1000</th>
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase tracking-widest">Min/Max</th>
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase tracking-widest">Description</th>
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase tracking-widest text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {services.map(s => (
                <tr key={s.id} className="hover:bg-white/2 transition-colors">
                  <td className="px-6 py-4 text-sm font-mono text-gray-500">{s.id}</td>
                  <td className="px-6 py-4">
                    <div className="text-sm font-medium text-white">{s.name}</div>
                    <div className="text-xs text-emerald-500 mt-0.5">{s.category}</div>
                  </td>
                  <td className="px-6 py-4 text-sm font-mono text-white">${s.rate.toFixed(2)}</td>
                  <td className="px-6 py-4 text-xs text-gray-500">{s.min_order} / {s.max_order}</td>
                  <td className="px-6 py-4 text-sm text-gray-400 max-w-xs truncate">{s.description}</td>
                  <td className="px-6 py-4 text-right">
                    <Link 
                      to={`/new-order?serviceId=${s.id}`}
                      className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-500 text-sm font-medium rounded-lg transition-colors"
                    >
                      <ShoppingCart className="w-4 h-4" />
                      Order
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const OrdersHistory = ({ token }: { token: string }) => {
  const [orders, setOrders] = useState<Order[]>([]);

  useEffect(() => {
    fetch('/api/orders', {
      headers: { 'Authorization': `Bearer ${token}` }
    })
      .then(res => res.json())
      .then(setOrders);
  }, [token]);

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-white mb-2">Order History</h2>
        <p className="text-gray-400">Monitor and track your social media growth progress</p>
      </div>

      <div className="bg-[#151619] rounded-2xl border border-white/5 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-white/5 border-b border-white/10">
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase tracking-widest">ID</th>
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase tracking-widest">Date</th>
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase tracking-widest">Service</th>
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase tracking-widest">Link</th>
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase tracking-widest">Quantity</th>
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase tracking-widest">Charge</th>
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase tracking-widest">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {orders.map(o => (
                <tr key={o.id} className="hover:bg-white/2 transition-colors">
                  <td className="px-6 py-4 text-sm font-mono text-gray-500">{o.id}</td>
                  <td className="px-6 py-4 text-xs text-gray-500">{new Date(o.created_at).toLocaleDateString()}</td>
                  <td className="px-6 py-4 text-sm text-white">{o.service_name}</td>
                  <td className="px-6 py-4 text-sm text-blue-400 hover:underline truncate max-w-[150px]">
                    <a href={o.link} target="_blank" rel="noreferrer">{o.link}</a>
                  </td>
                  <td className="px-6 py-4 text-sm font-mono text-white">{o.quantity}</td>
                  <td className="px-6 py-4 text-sm font-mono text-emerald-500">₹{o.charge.toFixed(2)}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                      o.status === 'Completed' ? 'bg-emerald-500/10 text-emerald-500' : 
                      o.status === 'Pending' ? 'bg-yellow-500/10 text-yellow-500' : 
                      o.status === 'Cancelled' ? 'bg-red-500/10 text-red-500' : 'bg-blue-500/10 text-blue-500'
                    }`}>
                      {o.status}
                    </span>
                  </td>
                </tr>
              ))}
              {orders.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-gray-500">No orders found. Place your first order today!</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const FriendsPanel = ({ token }: { token: string }) => {
  const [friends, setFriends] = useState<any[]>([]);
  const [pending, setPending] = useState<any[]>([]);
  const [sent, setSent] = useState<any[]>([]);
  const [searchUsername, setSearchUsername] = useState('');
  const [message, setMessage] = useState({ text: '', type: '' });

  const fetchFriends = async () => {
    try {
      const res = await fetch('/api/friends', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setFriends(data.friends);
        setPending(data.pending);
        setSent(data.sent);
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchFriends();
  }, [token]);

  const sendInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchUsername.trim()) return;
    
    try {
      const res = await fetch('/api/friends/request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
        body: JSON.stringify({ username: searchUsername })
      });
      const data = await res.json();
      
      if (res.ok) {
        setMessage({ text: data.message, type: 'success' });
        setSearchUsername('');
        fetchFriends();
      } else {
        setMessage({ text: data.error || 'Failed to send invite', type: 'error' });
      }
    } catch (err) {
      setMessage({ text: 'An error occurred', type: 'error' });
    }
    
    setTimeout(() => setMessage({ text: '', type: '' }), 3000);
  };

  const handleRequest = async (requestId: number, action: 'accept' | 'reject') => {
    try {
      const res = await fetch(`/api/friends/${action}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
        body: JSON.stringify({ requestId })
      });
      if (res.ok) {
        fetchFriends();
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-white mb-2 flex items-center gap-3">
          <Gamepad2 className="w-8 h-8 text-emerald-500" />
          My Squad
        </h2>
        <p className="text-gray-400">Manage your friends, send invites, and build your team.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Add Friend & Pending */}
        <div className="space-y-8">
          {/* Add Friend */}
          <div className="bg-[#151619] p-6 rounded-2xl border border-white/5">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <UserPlus className="w-5 h-5 text-emerald-500" />
              Add Player
            </h3>
            <form onSubmit={sendInvite} className="space-y-4">
              <div>
                <input 
                  type="text" 
                  value={searchUsername}
                  onChange={(e) => setSearchUsername(e.target.value)}
                  placeholder="Enter player username..." 
                  className="w-full bg-[#1a1b1e] border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                  required
                />
              </div>
              <button 
                type="submit"
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 px-4 rounded-xl transition-all flex items-center justify-center gap-2"
              >
                Send Invite
              </button>
              {message.text && (
                <div className={`p-3 rounded-xl text-sm ${message.type === 'success' ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20' : 'bg-red-500/10 text-red-500 border border-red-500/20'}`}>
                  {message.text}
                </div>
              )}
            </form>
          </div>

          {/* Pending Requests */}
          <div className="bg-[#151619] p-6 rounded-2xl border border-white/5">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <UserCheck className="w-5 h-5 text-yellow-500" />
              Pending Invites ({pending.length})
            </h3>
            
            {pending.length === 0 ? (
              <p className="text-gray-500 text-sm text-center py-4">No pending invites.</p>
            ) : (
              <div className="space-y-3">
                {pending.map(req => (
                  <div key={req.request_id} className="bg-[#1a1b1e] p-3 rounded-xl border border-white/5 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <img src={`https://api.dicebear.com/7.x/bottts/svg?seed=${req.username}`} alt="avatar" className="w-10 h-10 rounded-full bg-white/5 p-1" />
                      <div>
                        <p className="text-white font-bold text-sm">{req.username}</p>
                        <p className="text-gray-500 text-xs">Wants to join squad</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button onClick={() => handleRequest(req.request_id, 'accept')} className="p-2 bg-emerald-500/20 text-emerald-500 hover:bg-emerald-500 hover:text-white rounded-lg transition-colors">
                        <UserCheck className="w-4 h-4" />
                      </button>
                      <button onClick={() => handleRequest(req.request_id, 'reject')} className="p-2 bg-red-500/20 text-red-500 hover:bg-red-500 hover:text-white rounded-lg transition-colors">
                        <UserX className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Friends List */}
        <div className="lg:col-span-2">
          <div className="bg-[#151619] p-6 rounded-2xl border border-white/5 h-full">
            <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
              <Users className="w-5 h-5 text-emerald-500" />
              Active Squad ({friends.length})
            </h3>

            {friends.length === 0 ? (
              <div className="text-center py-12">
                <Gamepad2 className="w-16 h-16 text-gray-600 mx-auto mb-4 opacity-50" />
                <h4 className="text-lg font-bold text-gray-400 mb-2">Your squad is empty</h4>
                <p className="text-gray-500 text-sm">Send invites to other players to build your team.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {friends.map(friend => (
                  <div key={friend.id} className="bg-[#1a1b1e] p-4 rounded-xl border border-white/5 flex items-center gap-4 hover:border-emerald-500/30 transition-colors group">
                    <div className="relative">
                      <img src={`https://api.dicebear.com/7.x/bottts/svg?seed=${friend.username}`} alt="avatar" className="w-14 h-14 rounded-full bg-white/5 p-1 border border-white/10 group-hover:border-emerald-500/50 transition-colors" />
                      <div className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-emerald-500 border-2 border-[#1a1b1e] rounded-full"></div>
                    </div>
                    <div>
                      <p className="text-white font-bold text-lg">{friend.username}</p>
                      <p className="text-emerald-500 text-xs font-mono uppercase tracking-wider">Online • In Lobby</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const AddFunds = ({ token }: { token: string }) => {
  const [amount, setAmount] = useState('');
  const [transactionId, setTransactionId] = useState('');
  const [message, setMessage] = useState({ text: '', type: '' });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/payments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
        body: JSON.stringify({ amount: parseFloat(amount), transaction_id: transactionId })
      });
      if (res.ok) {
        setMessage({ text: 'Payment request submitted successfully! Admin will review it soon.', type: 'success' });
        setAmount('');
        setTransactionId('');
      } else {
        setMessage({ text: 'Failed to submit request.', type: 'error' });
      }
    } catch (err) {
      setMessage({ text: 'An error occurred.', type: 'error' });
    }
    setLoading(false);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-white mb-2">Add Funds</h2>
        <p className="text-gray-400">Add money to your wallet using UPI</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* QR Code Section */}
        <div className="bg-[#151619] p-8 rounded-2xl border border-white/5 text-center flex flex-col items-center justify-center">
          <div className="bg-white p-4 rounded-xl inline-block mb-6">
            <img 
              src="https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=upi://pay?pa=shivamjatav009@ybl&pn=SMM%20PRO&cu=INR" 
              alt="UPI QR Code" 
              className="w-48 h-48"
              referrerPolicy="no-referrer"
            />
          </div>
          
          <h3 className="text-xl font-bold text-white mb-2">Scan & Pay</h3>
          <p className="text-gray-400 mb-6 text-sm">Scan the QR code with PhonePe, GPay, Paytm, etc.</p>
          
          <div className="bg-[#1a1b1e] p-4 rounded-xl border border-white/10 w-full">
            <p className="text-sm text-gray-500 mb-1">Or pay directly to UPI ID:</p>
            <p className="text-lg font-mono text-emerald-500 font-bold select-all">shivamjatav009@ybl</p>
          </div>
        </div>

        {/* Form Section */}
        <div className="bg-[#151619] p-8 rounded-2xl border border-white/5">
          <h3 className="text-xl font-bold text-white mb-6">Submit Payment Details</h3>
          <p className="text-sm text-gray-400 mb-6">After making the payment, please submit the transaction details below to get your balance updated.</p>
          
          {message.text && (
            <div className={`p-4 rounded-xl mb-6 text-sm ${message.type === 'success' ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20' : 'bg-red-500/10 text-red-500 border border-red-500/20'}`}>
              {message.text}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-1">Amount Paid (₹)</label>
              <input 
                type="number" 
                step="0.01"
                required 
                value={amount}
                onChange={e => setAmount(e.target.value)}
                className="w-full bg-[#1a1b1e] border border-white/10 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-emerald-500/50" 
                placeholder="e.g. 100" 
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-1">Transaction ID / UTR</label>
              <input 
                type="text" 
                required 
                value={transactionId}
                onChange={e => setTransactionId(e.target.value)}
                className="w-full bg-[#1a1b1e] border border-white/10 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-emerald-500/50" 
                placeholder="e.g. 123456789012" 
              />
            </div>
            <button 
              type="submit" 
              disabled={loading}
              className="w-full bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold py-3 rounded-xl transition-all shadow-lg shadow-emerald-600/20 mt-4"
            >
              {loading ? 'Submitting...' : 'Submit Request'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

const AdminPanel = ({ token }: { token: string }) => {
  const [stats, setStats] = useState({ users: 0, orders: 0, revenue: 0, pendingPayments: 0 });
  const [activeTab, setActiveTab] = useState<'stats' | 'users' | 'orders' | 'services' | 'payments'>('stats');
  const [users, setUsers] = useState<User[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [payments, setPayments] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchStats();
    if (activeTab === 'users') fetchUsers();
    if (activeTab === 'orders') fetchOrders();
    if (activeTab === 'services') fetchServices();
    if (activeTab === 'payments') fetchPayments();
  }, [activeTab]);

  const fetchStats = async () => {
    const res = await fetch('/api/admin/stats', { headers: { 'Authorization': `Bearer ${token}` } });
    if (res.ok) setStats(await res.json());
  };

  const fetchUsers = async () => {
    const res = await fetch('/api/admin/users', { headers: { 'Authorization': `Bearer ${token}` } });
    if (res.ok) setUsers(await res.json());
  };

  const fetchOrders = async () => {
    const res = await fetch('/api/admin/orders', { headers: { 'Authorization': `Bearer ${token}` } });
    if (res.ok) setOrders(await res.json());
  };

  const fetchServices = async () => {
    const res = await fetch('/api/services');
    if (res.ok) setServices(await res.json());
  };

  const fetchPayments = async () => {
    const res = await fetch('/api/admin/payments', { headers: { 'Authorization': `Bearer ${token}` } });
    if (res.ok) setPayments(await res.json());
  };

  const addBalance = async (userId: number) => {
    const amount = prompt('Enter amount to add:');
    if (!amount) return;
    const res = await fetch('/api/admin/users/balance', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
      body: JSON.stringify({ userId, amount: parseFloat(amount) })
    });
    if (res.ok) fetchUsers();
  };

  const updateOrderStatus = async (orderId: number, status: string) => {
    const res = await fetch('/api/admin/orders/status', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
      body: JSON.stringify({ orderId, status })
    });
    if (res.ok) fetchOrders();
  };

  const handleAddService = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const serviceData = {
      name: formData.get('name'),
      category: formData.get('category'),
      rate: parseFloat(formData.get('rate') as string),
      min_order: parseInt(formData.get('min_order') as string),
      max_order: parseInt(formData.get('max_order') as string),
      description: formData.get('description'),
    };

    const res = await fetch('/api/admin/services', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
      body: JSON.stringify(serviceData)
    });
    
    if (res.ok) {
      e.currentTarget.reset();
      fetchServices();
    }
  };

  const deleteService = async (id: number) => {
    if (!confirm('Are you sure you want to delete this service?')) return;
    const res = await fetch(`/api/admin/services/${id}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${token}` }
    });
    if (res.ok) fetchServices();
  };

  const approvePayment = async (paymentId: number) => {
    if (!confirm('Mark this payment as successful and add balance?')) return;
    const res = await fetch('/api/admin/payments/approve', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
      body: JSON.stringify({ paymentId })
    });
    if (res.ok) fetchPayments();
  };

  const rejectPayment = async (paymentId: number) => {
    if (!confirm('Reject this payment?')) return;
    const res = await fetch('/api/admin/payments/reject', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
      body: JSON.stringify({ paymentId })
    });
    if (res.ok) fetchPayments();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">Admin Control Panel</h2>
          <p className="text-gray-400">Manage your SMM PRO users, orders, and services</p>
        </div>
        <div className="flex gap-2 bg-[#151619] p-1 rounded-xl border border-white/5 overflow-x-auto">
          {(['stats', 'users', 'orders', 'services', 'payments'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all whitespace-nowrap relative ${
                activeTab === tab ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/20' : 'text-gray-400 hover:text-white'
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
              {tab === 'payments' && stats.pendingPayments > 0 && (
                <span className="absolute -top-1 -right-1 flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {activeTab === 'stats' && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div className="bg-[#151619] p-8 rounded-2xl border border-white/5">
              <Users className="text-blue-500 mb-4 w-8 h-8" />
              <h3 className="text-gray-500 text-sm uppercase tracking-widest font-mono">Total Users</h3>
              <p className="text-4xl font-bold text-white mt-2">{stats.users}</p>
            </div>
            <div className="bg-[#151619] p-8 rounded-2xl border border-white/5">
              <ShoppingCart className="text-purple-500 mb-4 w-8 h-8" />
              <h3 className="text-gray-500 text-sm uppercase tracking-widest font-mono">Total Orders</h3>
              <p className="text-4xl font-bold text-white mt-2">{stats.orders}</p>
            </div>
            <div className="bg-[#151619] p-8 rounded-2xl border border-white/5">
              <DollarSign className="text-emerald-500 mb-4 w-8 h-8" />
              <h3 className="text-gray-500 text-sm uppercase tracking-widest font-mono">Total Revenue</h3>
              <p className="text-4xl font-bold text-white mt-2">₹{stats.revenue.toFixed(2)}</p>
            </div>
            <div className="bg-[#151619] p-8 rounded-2xl border border-white/5">
              <Wallet className="text-yellow-500 mb-4 w-8 h-8" />
              <h3 className="text-gray-500 text-sm uppercase tracking-widest font-mono">Pending Payments</h3>
              <p className="text-4xl font-bold text-white mt-2">{stats.pendingPayments}</p>
            </div>
          </div>

          <div className="bg-[#151619] p-8 rounded-2xl border border-white/5 max-w-md">
            <h3 className="text-xl font-bold text-white mb-4">Active Payment QR</h3>
            <p className="text-gray-400 text-sm mb-6">This is the QR code currently visible to users on the Add Funds page.</p>
            <div className="flex items-center gap-6">
              <div className="bg-white p-2 rounded-xl inline-block">
                <img 
                  src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=upi://pay?pa=shivamjatav009@ybl&pn=SMM%20PRO&cu=INR" 
                  alt="Active UPI QR" 
                  className="w-24 h-24"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div>
                <p className="text-sm text-gray-500 mb-1">UPI ID:</p>
                <p className="text-lg font-mono text-emerald-500 font-bold select-all">shivamjatav009@ybl</p>
              </div>
            </div>
          </div>
        </>
      )}

      {activeTab === 'users' && (
        <div className="bg-[#151619] rounded-2xl border border-white/5 overflow-hidden">
          <table className="w-full text-left">
            <thead className="bg-white/5 border-b border-white/10">
              <tr>
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase">ID</th>
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase">Username</th>
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase">Balance</th>
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase">Role</th>
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {users.map(u => (
                <tr key={u.id} className="hover:bg-white/2">
                  <td className="px-6 py-4 text-sm font-mono text-gray-500">{u.id}</td>
                  <td className="px-6 py-4 text-sm text-white font-medium">{u.username}</td>
                  <td className="px-6 py-4 text-sm font-mono text-emerald-500">₹{u.balance.toFixed(2)}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase ${u.role === 'admin' ? 'bg-purple-500/10 text-purple-500' : 'bg-gray-500/10 text-gray-500'}`}>
                      {u.role}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button onClick={() => addBalance(u.id)} className="text-emerald-500 hover:text-emerald-400 text-sm font-medium">Add Balance</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === 'orders' && (
        <div className="bg-[#151619] rounded-2xl border border-white/5 overflow-hidden">
          <table className="w-full text-left">
            <thead className="bg-white/5 border-b border-white/10">
              <tr>
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase">ID</th>
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase">User</th>
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase">Service</th>
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase">Charge</th>
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase">Status</th>
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {orders.map(o => (
                <tr key={o.id} className="hover:bg-white/2">
                  <td className="px-6 py-4 text-sm font-mono text-gray-500">{o.id}</td>
                  <td className="px-6 py-4 text-sm text-white">{o.username}</td>
                  <td className="px-6 py-4 text-sm text-gray-400">{o.service_name}</td>
                  <td className="px-6 py-4 text-sm font-mono text-emerald-500">₹{o.charge.toFixed(2)}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase ${
                      o.status === 'Completed' ? 'bg-emerald-500/10 text-emerald-500' : 
                      o.status === 'Pending' ? 'bg-yellow-500/10 text-yellow-500' : 
                      o.status === 'Cancelled' ? 'bg-red-500/10 text-red-500' : 'bg-blue-500/10 text-blue-500'
                    }`}>
                      {o.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <select 
                      value={o.status}
                      onChange={(e) => updateOrderStatus(o.id, e.target.value)}
                      className="bg-[#1a1b1e] border border-white/10 rounded-lg px-3 py-1 text-sm text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                    >
                      <option value="Pending">Pending</option>
                      <option value="Processing">Processing</option>
                      <option value="Completed">Completed</option>
                      <option value="Cancelled">Cancelled</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === 'services' && (
        <div className="space-y-8">
          <div className="bg-[#151619] p-6 rounded-2xl border border-white/5">
            <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
              <Plus className="text-emerald-500" />
              Add New Service
            </h3>
            <form onSubmit={handleAddService} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-1">Service Name</label>
                <input name="name" required className="w-full bg-[#1a1b1e] border border-white/10 rounded-xl px-4 py-2 text-white focus:ring-2 focus:ring-emerald-500/50" placeholder="e.g. Instagram Followers" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-1">Category</label>
                <input name="category" required className="w-full bg-[#1a1b1e] border border-white/10 rounded-xl px-4 py-2 text-white focus:ring-2 focus:ring-emerald-500/50" placeholder="e.g. Instagram" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-1">Rate per 1000 (₹)</label>
                <input name="rate" type="number" step="0.01" required className="w-full bg-[#1a1b1e] border border-white/10 rounded-xl px-4 py-2 text-white focus:ring-2 focus:ring-emerald-500/50" placeholder="2.50" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-1">Min Order</label>
                <input name="min_order" type="number" required className="w-full bg-[#1a1b1e] border border-white/10 rounded-xl px-4 py-2 text-white focus:ring-2 focus:ring-emerald-500/50" placeholder="10" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-1">Max Order</label>
                <input name="max_order" type="number" required className="w-full bg-[#1a1b1e] border border-white/10 rounded-xl px-4 py-2 text-white focus:ring-2 focus:ring-emerald-500/50" placeholder="10000" />
              </div>
              <div className="md:col-span-2 lg:col-span-3">
                <label className="block text-sm font-medium text-gray-400 mb-1">Description</label>
                <input name="description" required className="w-full bg-[#1a1b1e] border border-white/10 rounded-xl px-4 py-2 text-white focus:ring-2 focus:ring-emerald-500/50" placeholder="High quality, non-drop..." />
              </div>
              <div className="md:col-span-2 lg:col-span-3 mt-2">
                <button type="submit" className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 px-6 rounded-xl transition-all shadow-lg shadow-emerald-600/20">
                  Add Service
                </button>
              </div>
            </form>
          </div>

          <div className="bg-[#151619] rounded-2xl border border-white/5 overflow-hidden">
            <table className="w-full text-left">
              <thead className="bg-white/5 border-b border-white/10">
                <tr>
                  <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase">ID</th>
                  <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase">Service</th>
                  <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase">Rate</th>
                  <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase">Min/Max</th>
                  <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {services.map(s => (
                  <tr key={s.id} className="hover:bg-white/2">
                    <td className="px-6 py-4 text-sm font-mono text-gray-500">{s.id}</td>
                    <td className="px-6 py-4">
                      <div className="text-sm font-medium text-white">{s.name}</div>
                      <div className="text-xs text-emerald-500 mt-0.5">{s.category}</div>
                    </td>
                    <td className="px-6 py-4 text-sm font-mono text-white">₹{s.rate.toFixed(2)}</td>
                    <td className="px-6 py-4 text-xs text-gray-500">{s.min_order} / {s.max_order}</td>
                    <td className="px-6 py-4 text-right">
                      <button onClick={() => deleteService(s.id)} className="text-red-500 hover:text-red-400 p-2 rounded-lg hover:bg-red-500/10 transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'payments' && (
        <div className="bg-[#151619] rounded-2xl border border-white/5 overflow-hidden">
          <table className="w-full text-left">
            <thead className="bg-white/5 border-b border-white/10">
              <tr>
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase">ID</th>
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase">User</th>
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase">Amount</th>
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase">Transaction ID</th>
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase">Status</th>
                <th className="px-6 py-4 text-xs font-mono text-gray-500 uppercase text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {payments.map(p => (
                <tr key={p.id} className="hover:bg-white/2">
                  <td className="px-6 py-4 text-sm font-mono text-gray-500">{p.id}</td>
                  <td className="px-6 py-4 text-sm text-white">{p.username}</td>
                  <td className="px-6 py-4 text-sm font-mono text-emerald-500">₹{p.amount.toFixed(2)}</td>
                  <td className="px-6 py-4 text-sm font-mono text-gray-400">{p.transaction_id}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase ${
                      p.status === 'Successful' ? 'bg-emerald-500/10 text-emerald-500' : 
                      p.status === 'Pending' ? 'bg-yellow-500/10 text-yellow-500' : 'bg-red-500/10 text-red-500'
                    }`}>
                      {p.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    {p.status === 'Pending' && (
                      <div className="flex justify-end gap-2">
                        <button 
                          onClick={() => approvePayment(p.id)} 
                          className="bg-emerald-500/10 text-emerald-500 hover:bg-emerald-500/20 px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-colors"
                        >
                          Successful
                        </button>
                        <button 
                          onClick={() => rejectPayment(p.id)} 
                          className="bg-red-500/10 text-red-500 hover:bg-red-500/20 px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-colors"
                        >
                          Reject
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [token, setToken] = useState<string | null>(localStorage.getItem('token'));
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    if (token) {
      fetch('/api/user', {
        headers: { 'Authorization': `Bearer ${token}` }
      })
      .then(res => {
        if (res.ok) return res.json();
        throw new Error('Invalid token');
      })
      .then(setUser)
      .catch(() => {
        setToken(null);
        localStorage.removeItem('token');
      });
    }
  }, [token]);

  const handleLogin = (newToken: string, newUser: User) => {
    setToken(newToken);
    setUser(newUser);
    localStorage.setItem('token', newToken);
  };

  const handleLogout = () => {
    setToken(null);
    setUser(null);
    localStorage.removeItem('token');
  };

  const refreshUser = () => {
    if (token) {
      fetch('/api/user', {
        headers: { 'Authorization': `Bearer ${token}` }
      })
      .then(res => res.json())
      .then(setUser);
    }
  };

  return (
    <Router>
      <div className="flex min-h-screen bg-[#0a0b0d] text-gray-100 font-sans selection:bg-emerald-500/30 selection:text-emerald-200">
        <Sidebar user={user} onLogout={handleLogout} />
        
        <div className="flex-1 flex flex-col min-h-screen">
          <Navbar user={user} onLogout={handleLogout} />
          
          <main className="flex-1 pb-12">
            <Routes>
              <Route path="/" element={token ? <Navigate to="/dashboard" /> : <Navigate to="/login" />} />
              <Route path="/login" element={!token ? <LoginPage onLogin={handleLogin} type="login" /> : <Navigate to="/dashboard" />} />
              <Route path="/register" element={!token ? <LoginPage onLogin={handleLogin} type="register" /> : <Navigate to="/dashboard" />} />
              <Route path="/reset-password" element={!token ? <LoginPage onLogin={handleLogin} type="reset" /> : <Navigate to="/dashboard" />} />
              
              <Route path="/dashboard" element={token && user ? <Dashboard user={user} token={token} /> : <Navigate to="/login" />} />
              <Route path="/new-order" element={token && user ? <NewOrder token={token} onOrderSuccess={refreshUser} /> : <Navigate to="/login" />} />
              <Route path="/services" element={<ServicesList />} />
              <Route path="/orders" element={token ? <OrdersHistory token={token} /> : <Navigate to="/login" />} />
              <Route path="/add-funds" element={token ? <AddFunds token={token} /> : <Navigate to="/login" />} />
              <Route path="/friends" element={token ? <FriendsPanel token={token} /> : <Navigate to="/login" />} />
              <Route path="/admin" element={token && user?.role === 'admin' ? <AdminPanel token={token} /> : <Navigate to="/dashboard" />} />
            </Routes>
          </main>

          <footer className="border-t border-white/5 py-8 mt-auto">
            <div className="max-w-7xl mx-auto px-4 text-center">
              <p className="text-gray-500 text-sm">© 2026 SMM PRO. All rights reserved.</p>
              <div className="flex justify-center gap-6 mt-4">
                <a href="#" className="text-gray-600 hover:text-white transition-colors text-xs uppercase tracking-widest">Terms</a>
                <a href="#" className="text-gray-600 hover:text-white transition-colors text-xs uppercase tracking-widest">Privacy</a>
                <a href="https://wa.me/918929504104" target="_blank" rel="noreferrer" className="text-emerald-500 hover:text-emerald-400 transition-colors text-xs uppercase tracking-widest font-bold">WhatsApp: 8929504104</a>
              </div>
            </div>
          </footer>
        </div>
      </div>
    </Router>
  );
}
