export interface User {
  id: number;
  username: string;
  balance: number;
  role: 'user' | 'admin';
}

export interface Service {
  id: number;
  name: string;
  category: string;
  rate: number;
  min_order: number;
  max_order: number;
  description: string;
}

export interface Order {
  id: number;
  service_name: string;
  link: string;
  quantity: number;
  charge: number;
  status: string;
  created_at: string;
}
